export declare const getBlock: (options: {
    block: string;
    url: string;
    network: string;
}) => Promise<number>;
