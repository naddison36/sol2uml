export declare const shortBytes32: (bytes32: string) => string;
